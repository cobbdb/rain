
var map = null;
var geocoder = null;
var roofareanew, percentflushes;

var poly;
var count = 0;
var points = new Array();
var markers = new Array();
var icon_url = "http://labs.google.com/ridefinder/images/";
var tooltip;
var report=document.getElementById("status");
var mapExtension, identifyTask, layers, overlays;


function callWeather()
{
	var latLng = map.getCenter();
	
	/* // Old Weather.com XML Stuff
	$.ajax({
		url: "http://xoap.weather.com/weather/local/" +
			 "30339?cc=*&dayf=5&link=xoap&prod=xoap&par=1280627975&key=67af09483f7de963",
		dataType: "xml",
		success: function(xml_feed)
		{
			alert("XML Fetch Success!");
			$("#xml_dump").html("Hello Dan, I have some XML for you.");
		}
	});*/
	
}


function addIcon(icon) // Add icon properties
{
	icon.shadow= icon_url + "mm_20_shadow.png";
	icon.iconSize = new GSize(12, 20);
	icon.shadowSize = new GSize(22, 20);
	icon.iconAnchor = new GPoint(6, 20);
	icon.infoWindowAnchor = new GPoint(5, 1);
}


function showTooltip(marker) // Display tooltips
{
	tooltip.innerHTML = marker.tooltip;
	tooltip.style.display = "block";

	// Tooltip transparency specially for IE
	if(typeof(tooltip.style.filter) == "string")
	{
		tooltip.style.filter = "alpha(opacity:70)";
	}

	var currtype = map.getCurrentMapType().getProjection();
	var point= currtype.fromLatLngToPixel(map.fromDivPixelToLatLng(new GPoint(0,0),true),map.getZoom());
	var offset= currtype.fromLatLngToPixel(marker.getLatLng(),map.getZoom());
	var anchor = marker.getIcon().iconAnchor;
	var width = marker.getIcon().iconSize.width + 6;
	// var height = tooltip.clientHeight +18;
	var height = 10;
	var pos = new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(offset.x - point.x - anchor.x + width, offset.y - point.y -anchor.y - height)); 
	pos.apply(tooltip);
}


function CustomGetTileUrlRain(a,b)
{
	return "http://www.laudontech.com//save-the-rain//Z" + b + "/" + a.y + "_" + a.x + ".png"; // replace that with a "real" URL
	return G_PHYSICAL_MAP.getTileLayers()[0].getTileUrl(a,b);
}


function CustomGetTileUrlProjects(a,b)
{
	return "http://www.laudontech.com//save-the-rain//projecttiles//Z" + b + "/" + a.y + "_" + a.x + ".png"; // replace that with a "real" URL
	return G_PHYSICAL_MAP.getTileLayers()[0].getTileUrl(a,b);
}
    

function initialize()
{
	//$("#results").hide();
	
	var container = document.getElementById("mapcontent");
    map = new GMap2(container, {draggableCursor: 'crosshair', draggingCursor:"move"});

     //ESRI Stuff
    mapExtension = new esri.arcgis.gmaps.MapExtension(map);
    //identifyTask = new esri.arcgis.gmaps.IdentifyTask("http://209.134.48.186/ArcGIS/rest/services/BCRain/MapServer");
	identifyTask = new esri.arcgis.gmaps.IdentifyTask("http://gis.ncdc.noaa.gov/rest/services/cdo/all_stations/MapServer");
 
    tooltip = document.createElement("div");
    tooltip.className = "tooltip";
    map.getPane(G_MAP_MARKER_PANE).appendChild(tooltip);

    map.setUIToDefault();

	map.setMapType(G_SATELLITE_MAP);

    map.setCenter(new GLatLng(40.875501,-124.07827), 16);
	var hierarchy = new GHierarchicalMapTypeControl();
	hierarchy.addRelationship(G_SATELLITE_MAP, G_HYBRID_MAP, "Labels", true);
	map.addControl(hierarchy);
	 
    var copyrightCollection = new GCopyrightCollection('Map Data:')
	var copyright = new GCopyright(1, new GLatLngBounds(new GLatLng(-90, -180), new GLatLng(90,180)), 0, "Rainfall");
	copyrightCollection.addCopyright(copyright);

	var tilelayersProjects = new Array();

	tilelayersProjects[0] = new GTileLayer(copyrightCollection,4,11);
	tilelayersProjects[0].getTileUrl = function () { return "http://www.laudontech.com//zsevanston//blank2.png"; };
	tilelayersProjects[0].getOpacity = function () {return 1.0;};//of the non transparent part
	tilelayersProjects[0].isPng = function() {return true;};
	tilelayersProjects[1] = G_NORMAL_MAP.getTileLayers()[0];
	tilelayersProjects[2] = new GTileLayer(copyrightCollection,3,11);
	tilelayersProjects[2].getTileUrl = CustomGetTileUrlProjects
	tilelayersProjects[2].getOpacity = function () {return 0.7;};//of the non transparent part
	tilelayersProjects[2].isPng = function() {return true;};
	

	var tilelayersRain = new Array();

	tilelayersRain[0] = new GTileLayer(copyrightCollection,4,11);
	tilelayersRain[0].getTileUrl = function () { return "http://www.laudontech.com//zsevanston//blank2.png"; };
	tilelayersRain[0].getOpacity = function () {return 1.0;};//of the non transparent part
	tilelayersRain[0].isPng = function() {return true;};
	tilelayersRain[1] = G_NORMAL_MAP.getTileLayers()[0];
	tilelayersRain[2] = new GTileLayer(copyrightCollection,3,11);
	tilelayersRain[2].getTileUrl = CustomGetTileUrlRain
	tilelayersRain[2].getOpacity = function () {return 0.7;};//of the non transparent part
	tilelayersRain[2].isPng = function() {return true;};
	
		
			
	var GMapTypeOptions = new Object();
	GMapTypeOptions.minResolution = 1;
	GMapTypeOptions.maxResolution = 11;
	GMapTypeOptions.errorMessage = "No map data available";
		
	var custommapRain = new GMapType(tilelayersRain, new GMercatorProjection(24), "Rainfall", GMapTypeOptions);
	custommapRain.getTextColor = function() {return "#ffffff";};
	map.addMapType(custommapRain);
	
	var custommapProjects = new GMapType(tilelayersProjects, new GMercatorProjection(24), "Projects", GMapTypeOptions);
	custommapProjects.getTextColor = function()
	{
		return "#ffffff";
	};
	map.addMapType(custommapProjects);
	
	geocoder = new GClientGeocoder();
	map.disableDoubleClickZoom()
	
	GEvent.addListener(map, "click", leftClick);
	
		
    GEvent.addListener(map, 'maptypechanged', function()
	{
		map.clearOverlays();
		var newMapType = map.getCurrentMapType().getName(true);   
		if( newMapType == "Rainfall" )
		{
			var zoomlevel = map.getZoom();
			if( zoomlevel >= 10 )
				map.setZoom(9);
		}
		else if( newMapType == "Projects" )
		{
			map.setZoom(1);
			map.setCenter( new GLatLng(40.875501,-124.07827), 1 );
			AddKML();
		}
    });
}

function leftClick(overlay, point)
{
	if( point )
	{
		count++;

		// Red marker icon
		var icon = new GIcon();
		icon.image = icon_url + "mm_20_red.png";
		addIcon(icon);

		// Make markers draggable
		var marker = new GMarker(point, {icon:icon, draggable:true, bouncy:false, dragCrossMove:true});
		map.addOverlay(marker);
		marker.content = count;
		markers.push(marker);
		marker.tooltip = "Point "+ count;
		
		if(markers.length > 2)
			document.getElementById("finished").disabled = false;
			
		GEvent.addListener(marker, "mouseover", function()
		{
			//showTooltip(marker);
		});

		GEvent.addListener(marker, "mouseout", function()
		{
			tooltip.style.display = "none";
		});

		// Drag listener
		GEvent.addListener(marker, "drag", function()
		{
			tooltip.style.display= "none";
			drawOverlay();
		});

		// Click listener to remove a marker
		GEvent.addListener(marker, "click", function()
		{
			tooltip.style.display = "none";

			// Find out which marker to remove
			for(var n = 0; n < markers.length; n++)
			{
				if(markers[n] == marker)
				{
					map.removeOverlay(markers[n]);
					break;
				}
			}

			// Shorten array of markers and adjust counter
			markers.splice(n, 1);
			if(markers.length == 0)
				count = 0;
			else
			{
				count = markers[markers.length-1].content;
				drawOverlay();
			}
		});
		
		drawOverlay();
	}
}	

function toggleMode()
{
	if(markers.length > 1)
		drawOverlay();
}
 
function drawOverlay()
{
 	if (poly)
	{
		map.removeOverlay(poly);
	}
	
	points.length = 0;
	for (i = 0; i < markers.length; i++)
		points.push(markers[i].getLatLng());
	
	points.push(markers[0].getLatLng());
	poly = new GPolygon(points, "#ff0000", 2, .9, "#ff0000", .2);
	var roofarea = poly.getArea();
  	//if (roofarea >=1500){
	
	//alert("Please draw a smaller area!");
  	//clearMap();
 	//}
	var unit = "m&sup2;";
	document.getElementById("status").innerHTML =  roofarea.toFixed(1) + unit + " / " + Math.round(roofarea.toFixed(1)*10.7639) + "ft&sup2;";
	roofareanew = roofarea.toFixed(1);
    map.addOverlay(poly);
}

function clearMap()
{
    /*document.getElementById("finished").disabled = true;
	//$("#results").hide();
	document.getElementById("raining").style.backgroundImage = "url(images/blank.gif)";
	document.getElementById("resultsimage").src = "images/blank.gif";
	document.getElementById("corn").innerHTML= "";
	document.getElementById("soyabeans").innerHTML= "";
	document.getElementById("rice").innerHTML= "";
	document.getElementById("grain").innerHTML= "";
	document.getElementById("grow").innerHTML= "";*/

	// Clear current map and reset globals
	var valoare="100";
	map.clearOverlays();
    document.getElementById("rainfall").innerHTML= "";
	document.getElementById("harvest").innerHTML= "";
	//document.getElementById("flush").innerHTML= "pending... ";

	//Animate(displayed,(parseFloat($("#over1").css("height"))-(170/100)*valoare)/(displayed));

	points.length = 0;
	markers.length = 0;
	count = 0;
	document.getElementById("status").innerHTML= "&nbsp;";
}


function showAddress(address)
{
	var address = document.getElementById('addressbox').value;     
	clearMap();

	if (geocoder)
	{
		geocoder.getLatLng(address, function(point)
		{
			if (!point)
				alert(address + " not found");
			else
			{
				//alert(point);
				map.setMapType(G_SATELLITE_MAP);
				map.setCenter(point, 17);
				map.clearOverlays();
			}
		});
	}
}


function removeAll()
{
	map.clearOverlays();
	var boxes = document.getElementsByName("box");
	
	for(var i = 0; i < boxes.length; i++)
		boxes[i].checked = false;
}


function finisheddigitizing()
{
	document.getElementById("finished").disabled = true;
	document.getElementById("rainfall").innerHTML= "determining rainfall...";
	document.getElementById("harvest").innerHTML= "pending...";
	
	callWeather();
		
	//document.getElementById("raining").style.backgroundImage = "url(images/raining.gif)";
	var rainfall;
	//ESRI Stuff:
	
	var identifyParameters = new esri.arcgis.gmaps.IdentifyParameters();
	
	latLng = map.getCenter();
	identifyParameters.geometry = latLng; // location where the user clicked on the map
	//identifyParameters.geometry = new esri.geometry.Point(latLng.lng(), latLng.lat(), new esri.SpatialReference({ wkid: 2163 }));
	identifyParameters.tolerance = 3;
	identifyParameters.layerIds = [ 8 ];
	identifyParameters.layerOption = "all";
	identifyParameters.bounds = map.getBounds();
	var mapSize = map.getSize();
	identifyParameters.width = mapSize.width;
	identifyParameters.height = mapSize.height;
	
	//alert("(Lat, Long) = (" + latLng.lng() + "," + latLng.lat() + ")");

	identifyTask.execute(identifyParameters, function(response, error)
	{
		if( hasErrorOccurred(error) )
			return;
		
		//alert(latLng);
		getattributes(response, latLng);
		
		for( var i = 0; i < markers.length; i++ )
		{  
			var marker = markers[i];  
			marker.hide();
		}
		
		var polycenter = poly.getBounds().getCenter();
		map.setCenter(polycenter);
		  
		  
		rainfall2=rainfall2/1000;
		//alert(rainfall2);	
		totalRainfall=Math.round((roofareanew*rainfall2)*1000);
		
		//var corn = Math.round(totalRainfall/585);
		//var soyabeans =  Math.round(totalRainfall/1925);
		//var rice = 	Math.round(totalRainfall/1550);
		//var grain = Math.round(totalRainfall/730);
		
		/*document.getElementById("grow").innerHTML= "<a href=\"http://www.clw.csiro.au/issues/water/water_for_food.html#howmuch\" target=\"_blank\" style=\"text-decoration:underline;\">You could grow...</a>";
		document.getElementById("corn").innerHTML= corn + "kg";
		document.getElementById("soyabeans").innerHTML= soyabeans + "kg";
		document.getElementById("rice").innerHTML= rice + "kg";
		document.getElementById("grain").innerHTML= grain + "kg";*/
		
		document.getElementById("rainfall").innerHTML= rainfall2*1000 + "mm / " + Math.round(rainfall2*1000*0.03937) + "in";
		document.getElementById("harvest").innerHTML= totalRainfall + "L / " + Math.round(totalRainfall*0.26417) + "gal";
		//totalFlushes=Math.round(totalRainfall/6);
		//document.getElementById("flush").innerHTML= totalFlushes + " times!";
		//percentFlushes = (100-((totalFlushes/100000)*100));
		//alert(percentFlushes);
		//if (percentFlushes <= 0) {percentFlushes = 0};

		//rainfall2=500;
		//var valoare=Math.round(percentFlushes) + "";
		//document.getElementById("raining").style.backgroundImage = "url(images/blank.gif)";
		//document.getElementById("resultsimage").src = "images/results2.png";
		//ChangeFill(percentFlushes);
		
		//Animate(displayed,(parseFloat($("#over1").css("height"))-(170/100)*valoare)/(displayed));
	
	});
		  
	//$("#results").show();
	//document.getElementById("finished").disabled = true;		  
}


function getattributes(response, point)
{
	// aggregate the result per map service layer
	
	var idResults = response.identifyResults;
	layers = { "0" : [] };
	for(var i = 0; i < idResults.length; i++)
	{
		var result = idResults[i];
		layers[result.layerId].push(result);
	}
	
	// create and show the data
	var tabs = [];
	for(var layerId in layers)
	{
		var results = layers[layerId];
		var count = results.length;
		
		if(count == 0)
		{
			alert ("You have selected an area not covered by the precipitation data.  An mean annual rainfall of 500mm will be used.");
			rainfall2 = 500;
			return rainfall2;
		}
		
		for(var j = 0; j < count; j++)
		{
			var attributes = results[j].feature.attributes;
			//var rainfall=results[0].feature.attributes;
			
			for(var key in attributes)
				alert(key + " = " + attributes[key]);
			
			//rainfall2 = (attributes["FID_PROVIN"]);
			rainfall2 = (attributes["NV_ANN_PRE"]);
			return rainfall2;
		}
	}
}


function addMapServiceLayer(layer, error)
{
	// display error message (if any) and return
	if (hasErrorOccurred(error))
		return;

	// add layer to the map
	mapExtension.addToMap(layer);
}


function hasErrorOccurred(error)
{
	if (error)
	{
		alert("Error " + error.code + ": " + (error.message || (error.details && error.details.join(" ")) || "Unknown error" ));
		return true;
	}
	return false;
}


function QuickZoom(location)
{
	switch (location)
	{
		case 'Kenya': map.setCenter(new GLatLng(0.045308,  37.659934), 20); map.setMapType(G_SATELLITE_MAP); clearMap();break;
		case 'Zimbabwe': map.setCenter(new GLatLng(-18.969715, 29.591935), 18); map.setMapType(G_SATELLITE_MAP); clearMap();break;
		case 'Ghana': map.setCenter(new GLatLng(6.588955, -0.287125), 19); map.setMapType(G_SATELLITE_MAP); clearMap();break;
		case 'India': map.setCenter(new GLatLng(21.567350, 76.135597), 19); map.setMapType(G_SATELLITE_MAP); clearMap();break;
		case 'Brazil': map.setCenter(new GLatLng(-20.554142, -54.631976), 17); map.setMapType(G_SATELLITE_MAP); clearMap();break;
		default: ;
	}
}


function AddKML()
{
	if( GBrowserIsCompatible() )
	{
		geoXml = new GGeoXml("http://www.save-the-rain.com/world-bank/kmz/doc.kml");
		map.addOverlay(geoXml);
	}
}


function changeDivImage()
{
	document.getElementById("raining").style.backgroundImage = "url(../images/raining.gif)";
}


function mapInit()
{
	initialize();
	
	//select all the a tag with name equal to modal
	$('a[name=modal]').click(function(e)
	{
		//Cancel the link behavior
		e.preventDefault();

		//Get the A tag
		var id = $(this).attr('href');

		//Get the screen height and width
		var maskHeight = $(document).height();
		var maskWidth = $(window).width();

		//Set heigth and width to mask to fill up the whole screen
		$('#mask').css({'width':maskWidth,'height':maskHeight});

		//transition effect		
		$('#mask').fadeIn(1000);	
		$('#mask').fadeTo("slow",0.8);	

		//Get the window height and width
		var winH = $(window).height();
		var winW = $(window).width();

		//Set the popup window to center
		$(id).css('top',  winH/2-$(id).height()/2);
		$(id).css('left', winW/2-$(id).width()/2);

		//transition effect
		$(id).fadeIn(2000); 
	
	});
	
	//if close button is clicked
	$('.window .close').click(function (e)
	{
		//Cancel the link behavior
		e.preventDefault();
		$('#mask').hide();
		$('.window').hide();
	});		
	
	//if mask is clicked
	$('#mask').click(function ()
	{
		$(this).hide();
		$('.window').hide();
	});			
	
}